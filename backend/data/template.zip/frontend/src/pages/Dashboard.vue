<template>
  <div class="dashboard">
    <!-- 页面头部 -->
    <div class="dashboard-header">
      <div class="header-content">
        <div class="welcome-section">
          <h1>欢迎回来，{{ userStore.user?.name || '用户' }}</h1>
          <p>今天是 {{ currentDate }}，您有 {{ totalProjects }} 个项目</p>
        </div>
        <div class="header-actions">
          <n-button
            type="primary"
            size="large"
            @click="createNewProject"
            class="create-btn"
          >
            <template #icon>
              <n-icon><AddIcon /></n-icon>
            </template>
            创建新项目
          </n-button>
        </div>
      </div>
    </div>

    <!-- 统计卡片 -->
    <div class="stats-grid">
      <n-card class="stat-card">
        <n-statistic
          label="总项目数"
          :value="totalProjects"
          :value-style="{ color: '#3182CE' }"
        >
          <template #prefix>
            <n-icon size="24" color="#3182CE">
              <FolderIcon />
            </n-icon>
          </template>
        </n-statistic>
      </n-card>

      <n-card class="stat-card">
        <n-statistic
          label="进行中"
          :value="inProgressProjects"
          :value-style="{ color: '#D69E2E' }"
        >
          <template #prefix>
            <n-icon size="24" color="#D69E2E">
              <ClockIcon />
            </n-icon>
          </template>
        </n-statistic>
      </n-card>

      <n-card class="stat-card">
        <n-statistic
          label="已完成"
          :value="completedProjects"
          :value-style="{ color: '#38A169' }"
        >
          <template #prefix>
            <n-icon size="24" color="#38A169">
              <CheckIcon />
            </n-icon>
          </template>
        </n-statistic>
      </n-card>

      <n-card class="stat-card">
        <n-statistic
          label="本月新增"
          :value="newThisMonth"
          :value-style="{ color: '#E53E3E' }"
        >
          <template #prefix>
            <n-icon size="24" color="#E53E3E">
              <TrendingUpIcon />
            </n-icon>
          </template>
        </n-statistic>
      </n-card>
    </div>

    <!-- 主要内容区域 -->
    <div class="dashboard-content">
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/stores/user'
import {
  NButton, NIcon, NCard, NStatistic, NInput, NSelect, NTag, NProgress, NPagination
} from 'naive-ui'

// 图标组件
const AddIcon = () => '➕'
const FolderIcon = () => '📁'
const ClockIcon = () => '⏰'
const CheckIcon = () => '✅'
const TrendingUpIcon = () => '📈'
const SearchIcon = () => '🔍'
const CloseIcon = () => '❌'

const router = useRouter()
const userStore = useUserStore()

// 响应式数据
const searchKeyword = ref('')
const statusFilter = ref('')
const currentPage = ref(1)
const pageSize = ref(8)
const currentProject = ref<Project | null>(null)
const updateInterval = ref<number | null>(null)

// 状态选项
const statusOptions = [
  { label: '全部状态', value: '' },
  { label: '草稿', value: 'draft' },
  { label: '进行中', value: 'in_progress' },
  { label: '已完成', value: 'completed' },
  { label: '失败', value: 'failed' }
]

// 快速操作
const quickActions = [
  { key: 'create', label: '创建项目', icon: AddIcon, type: 'primary' },
  { key: 'import', label: '导入项目', icon: FolderIcon, type: 'default' },
  { key: 'export', label: '导出数据', icon: TrendingUpIcon, type: 'default' },
  { key: 'settings', label: '设置', icon: ClockIcon, type: 'default' }
]

// 计算属性
const currentDate = computed(() => {
  return new Date().toLocaleDateString('zh-CN', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    weekday: 'long'
  })
})

const totalProjects = computed(() => 0)

const inProgressProjects = computed(() => 
  0
)

const completedProjects = computed(() => 
  0
)

const newThisMonth = computed(() => {
  0
})



// 实时更新
const startRealTimeUpdates = () => {
  updateInterval.value = window.setInterval(() => {
    // 这里可以调用 API 获取最新数据
    // 目前使用模拟数据，实际项目中应该调用 projectStore.fetchProjects()
    console.log('实时更新项目数据...')
  }, 30000) // 30秒更新一次
}

const stopRealTimeUpdates = () => {
  if (updateInterval.value) {
    clearInterval(updateInterval.value)
    updateInterval.value = null
  }
}

// 生命周期
onMounted(() => {  
  // 启动实时更新
  startRealTimeUpdates()
})

onUnmounted(() => {
  stopRealTimeUpdates()
})
</script>

<style scoped>
.dashboard {
  padding: var(--spacing-lg);
  background: var(--background-color);
  min-height: 100vh;
}

/* 页面头部 */
.dashboard-header {
  margin-bottom: var(--spacing-xl);
}

.header-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: var(--spacing-lg);
  background: white;
  border-radius: var(--border-radius-lg);
  box-shadow: var(--shadow-sm);
}

.welcome-section h1 {
  margin: 0 0 var(--spacing-sm) 0;
  color: var(--primary-color);
  font-size: 1.5rem;
  font-weight: bold;
}

.welcome-section p {
  margin: 0;
  color: var(--text-secondary);
}

.create-btn {
  background: linear-gradient(135deg, var(--primary-color), var(--accent-color));
  border: none;
  font-weight: 600;
}

/* 统计卡片 */
.stats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: var(--spacing-lg);
  margin-bottom: var(--spacing-xl);
}

.stat-card {
  text-align: center;
  transition: transform 0.3s ease;
}

.stat-card:hover {
  transform: translateY(-4px);
}

/* 主要内容区域 */
.dashboard-content {
  display: grid;
  grid-template-columns: 1fr 300px;
  gap: var(--spacing-xl);
}

/* 项目列表区域 */
.projects-section {
  background: white;
  border-radius: var(--border-radius-lg);
  padding: var(--spacing-lg);
  box-shadow: var(--shadow-sm);
}

.section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: var(--spacing-lg);
  flex-wrap: wrap;
  gap: var(--spacing-md);
}

.section-header h2 {
  margin: 0;
  color: var(--primary-color);
  font-size: 1.25rem;
  font-weight: bold;
}

.filter-controls {
  display: flex;
  gap: var(--spacing-md);
  align-items: center;
}

.search-input {
  width: 200px;
}

.status-filter {
  width: 120px;
}

/* 项目网格 */
.projects-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: var(--spacing-lg);
  margin-bottom: var(--spacing-lg);
}

.project-card {
  cursor: pointer;
  transition: all 0.3s ease;
  border: 1px solid var(--border-color);
}

.project-card:hover {
  transform: translateY(-2px);
  box-shadow: var(--shadow-md);
}

.project-card--active {
  border-color: var(--primary-color);
  box-shadow: 0 0 0 2px rgba(49, 130, 206, 0.2);
}

.project-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: var(--spacing-sm);
}

.project-header h3 {
  margin: 0;
  font-size: 1.1rem;
  color: var(--primary-color);
  flex: 1;
}

.project-description {
  margin: 0 0 var(--spacing-md) 0;
  color: var(--text-secondary);
  font-size: 0.9rem;
  line-height: 1.4;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.project-progress {
  margin-bottom: var(--spacing-md);
}

.progress-text {
  font-size: 0.8rem;
  color: var(--text-secondary);
  margin-left: var(--spacing-sm);
}

.project-meta {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.created-time {
  font-size: 0.8rem;
  color: var(--text-disabled);
}

.project-actions {
  display: flex;
  gap: var(--spacing-sm);
}

/* 分页 */
.pagination-wrapper {
  display: flex;
  justify-content: center;
  margin-top: var(--spacing-lg);
}

/* 右侧面板 */
.sidebar-panel {
  display: flex;
  flex-direction: column;
  gap: var(--spacing-lg);
}

.current-project-card,
.system-status-card,
.quick-actions-card {
  background: white;
  border-radius: var(--border-radius-lg);
  box-shadow: var(--shadow-sm);
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.card-header h3 {
  margin: 0;
  color: var(--primary-color);
  font-size: 1.1rem;
  font-weight: bold;
}

.project-detail h4 {
  margin: 0 0 var(--spacing-sm) 0;
  color: var(--primary-color);
  font-size: 1.1rem;
}

.project-detail p {
  margin: 0 0 var(--spacing-md) 0;
  color: var(--text-secondary);
  font-size: 0.9rem;
}

.project-stats {
  margin-bottom: var(--spacing-lg);
}

.stat-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: var(--spacing-sm);
}

.stat-item .label {
  color: var(--text-secondary);
  font-size: 0.9rem;
}

.stat-item .value {
  color: var(--primary-color);
  font-weight: 500;
}

.project-actions {
  display: flex;
  gap: var(--spacing-sm);
}

.status-list {
  display: flex;
  flex-direction: column;
  gap: var(--spacing-sm);
}

.status-item {
  display: flex;
  align-items: center;
  gap: var(--spacing-sm);
  font-size: 0.9rem;
  color: var(--text-secondary);
}

.quick-actions {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: var(--spacing-sm);
}

.quick-action-btn {
  width: 100%;
}

/* 响应式设计 */
@media (max-width: 1024px) {
  .dashboard-content {
    grid-template-columns: 1fr;
  }
  
  .sidebar-panel {
    order: -1;
  }
}

@media (max-width: 768px) {
  .dashboard {
    padding: var(--spacing-md);
  }
  
  .header-content {
    flex-direction: column;
    gap: var(--spacing-md);
    text-align: center;
  }
  
  .section-header {
    flex-direction: column;
    align-items: stretch;
  }
  
  .filter-controls {
    flex-direction: column;
  }
  
  .search-input,
  .status-filter {
    width: 100%;
  }
  
  .projects-grid {
    grid-template-columns: 1fr;
  }
  
  .quick-actions {
    grid-template-columns: 1fr;
  }
}

@media (max-width: 480px) {
  .stats-grid {
    grid-template-columns: 1fr;
  }
  
  .project-meta {
    flex-direction: column;
    align-items: flex-start;
    gap: var(--spacing-sm);
  }
}
</style>