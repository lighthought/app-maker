# 项目部署指南

## 项目信息
- **项目名称**: {{PROJECT_NAME}}
- **项目 GUID**: {{PROJECT_GUID}}
- **生成时间**: {{CREATED_AT}}

## 前置条件

### 必需软件
- Docker >= 20.10
- Docker Compose >= 2.0
- Make (可选，用于简化命令)

### 网络配置
项目需要加入 `app-maker-network` 网络。如果网络不存在，请先创建：

```bash
docker network create app-maker-network
```

### Traefik 配置
项目使用 Traefik 作为反向代理。确保 Traefik 服务正在运行并监听 `app-maker-network`。

## 访问地址

部署成功后，您可以通过以下地址访问项目：

- **前端**: http://{{PROJECT_GUID}}.app-maker.localhost
- **后端 API**: http://{{PROJECT_GUID}}-api.app-maker.localhost

## 快速开始

### 使用 Make 命令（推荐）

#### 1. 构建项目
```bash
make build-dev
```

#### 2. 启动项目
```bash
make run-dev
```

项目启动后会自动显示访问地址。

#### 3. 查看日志
```bash
make logs-dev
```

#### 4. 停止项目
```bash
make stop-dev
```

#### 5. 清理项目（包括数据卷）
```bash
make clean-dev
```

### 使用 Docker Compose 命令

如果没有 Make，可以直接使用 Docker Compose：

#### 1. 构建项目
```bash
docker-compose build
```

#### 2. 启动项目
```bash
docker-compose up -d
```

#### 3. 查看日志
```bash
docker-compose logs -f
```

#### 4. 停止项目
```bash
docker-compose down
```

#### 5. 清理项目（包括数据卷）
```bash
docker-compose down -v
```

## 服务说明

### 前端服务 (frontend)
- **端口**: {{FRONTEND_PORT}}
- **技术栈**: Vue.js + Vite
- **环境变量**: 
  - `VITE_API_BASE_URL`: 后端 API 地址
  - `VITE_API_TIMEOUT`: API 超时时间

### 后端服务 (backend)
- **端口**: {{BACKEND_PORT}}
- **技术栈**: Go + Gin
- **健康检查**: `/api/v1/health`
- **环境变量**:
  - `APP_SECRET_KEY`: 应用密钥
  - `DATABASE_PASSWORD`: 数据库密码
  - `REDIS_PASSWORD`: Redis 密码
  - `JWT_SECRET_KEY`: JWT 密钥

### 数据库服务 (postgres)
- **类型**: PostgreSQL 15
- **数据库名**: {{PROJECT_GUID}}_db
- **用户名**: {{PROJECT_GUID}}_user
- **密码**: {{DATABASE_PASSWORD}}
- **数据持久化**: Docker volume `postgres_data`

### 缓存服务 (redis)
- **类型**: Redis 7
- **密码**: {{REDIS_PASSWORD}}
- **数据持久化**: Docker volume `redis_data`

## 健康检查

检查所有服务的健康状态：

```bash
make health
```

或手动检查：

```bash
# 检查后端 API
curl http://{{PROJECT_GUID}}-api.app-maker.localhost/api/v1/health

# 检查前端
curl http://{{PROJECT_GUID}}.app-maker.localhost
```

## 调试

### 进入容器 Shell

```bash
# 后端容器
make shell-backend
# 或
docker-compose exec backend sh

# 前端容器
make shell-frontend
# 或
docker-compose exec frontend sh

# 数据库
make shell-db
# 或
docker-compose exec postgres psql -U {{PROJECT_GUID}}_user -d {{PROJECT_GUID}}_db
```

### 查看特定服务日志

```bash
# 后端日志
docker-compose logs -f backend

# 前端日志
docker-compose logs -f frontend

# 数据库日志
docker-compose logs -f postgres

# Redis 日志
docker-compose logs -f redis
```

## 常见问题

### 1. 无法访问项目地址

**问题**: 访问 `http://{{PROJECT_GUID}}.app-maker.localhost` 无响应

**解决方案**:
1. 确认 Traefik 服务正在运行
2. 确认项目容器已启动: `docker-compose ps`
3. 确认网络连接正常: `docker network inspect app-maker-network`
4. 检查 Traefik 日志: `docker logs traefik-dev`

### 2. 数据库连接失败

**问题**: 后端无法连接到数据库

**解决方案**:
1. 确认数据库容器已启动: `docker-compose ps postgres`
2. 检查数据库健康状态: `docker-compose exec postgres pg_isready`
3. 验证数据库密码是否正确
4. 查看后端日志: `docker-compose logs backend`

### 3. Redis 连接失败

**问题**: 后端无法连接到 Redis

**解决方案**:
1. 确认 Redis 容器已启动: `docker-compose ps redis`
2. 检查 Redis 健康状态: `docker-compose exec redis redis-cli ping`
3. 验证 Redis 密码是否正确
4. 查看后端日志: `docker-compose logs backend`

### 4. 前端无法访问后端 API

**问题**: 前端调用后端 API 失败

**解决方案**:
1. 确认后端服务正常: `curl http://{{PROJECT_GUID}}-api.app-maker.localhost/api/v1/health`
2. 检查前端环境变量 `VITE_API_BASE_URL` 是否正确
3. 检查 CORS 配置
4. 查看浏览器控制台错误信息

### 5. 端口冲突

**问题**: 容器启动失败，提示端口被占用

**解决方案**:
1. 检查端口占用: `netstat -tuln | grep <PORT>`
2. 修改 docker-compose.yml 中的端口映射
3. 或停止占用端口的其他服务

## 数据备份

### 备份数据库

```bash
docker-compose exec postgres pg_dump -U {{PROJECT_GUID}}_user {{PROJECT_GUID}}_db > backup_$(date +%Y%m%d_%H%M%S).sql
```

### 恢复数据库

```bash
docker-compose exec -T postgres psql -U {{PROJECT_GUID}}_user {{PROJECT_GUID}}_db < backup.sql
```

### 备份 Redis

```bash
docker-compose exec redis redis-cli --rdb /data/dump.rdb
docker cp $(docker-compose ps -q redis):/data/dump.rdb ./redis_backup_$(date +%Y%m%d_%H%M%S).rdb
```

## 生产部署

对于生产环境部署，建议：

1. **使用 HTTPS**: 配置 Traefik 的 Let's Encrypt 证书
2. **修改密码**: 更改所有默认密码
3. **资源限制**: 在 docker-compose.yml 中添加资源限制
4. **日志管理**: 配置日志轮转和集中日志收集
5. **监控**: 添加 Prometheus + Grafana 监控
6. **备份策略**: 定期备份数据库和重要数据

### 生产环境配置示例

```yaml
# 在 docker-compose.prod.yml 中添加资源限制
services:
  backend:
    deploy:
      resources:
        limits:
          cpus: '2.0'
          memory: 2G
        reservations:
          cpus: '1.0'
          memory: 1G
```

## 更新项目

### 更新代码

```bash
# 1. 停止项目
make stop-dev

# 2. 更新代码（通过 Git 或其他方式）
git pull origin main

# 3. 重新构建
make build-dev

# 4. 启动项目
make run-dev
```

### 更新依赖

```bash
# 后端
docker-compose exec backend go mod tidy

# 前端
docker-compose exec frontend npm install
```

## 支持

如有问题，请联系:
- **项目地址**: https://github.com/lighthought/app-maker
- **邮箱**: qqjack2012@gmail.com
- **Issue**: https://github.com/lighthought/app-maker/issues

---

**注意**: 本文档由 App-Maker 自动生成，某些配置可能需要根据实际情况调整。

